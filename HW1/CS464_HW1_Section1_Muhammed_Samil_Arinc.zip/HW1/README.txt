You can open the files either with the colab links or using them as *.py files.
The q2main.py is not giving everything as output but that are written on report.pdf. That's because, I did not write a funciton for each of the conditions. Therefore, you can verify them in my report. 

The other 2 files writes everything for each step; however, you should change file location if you want to use them with your dataset. Furthermore, you may comment "from google.colab import drive" line if you will not use the datasets from collab. 